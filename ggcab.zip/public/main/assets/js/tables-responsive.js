$(document).ready(function() {

	$('.table-responsive').responsiveTable({
		'stickyTableHeader': false,
		'focusBtnIcon': 'fa fa-star'
	});

});